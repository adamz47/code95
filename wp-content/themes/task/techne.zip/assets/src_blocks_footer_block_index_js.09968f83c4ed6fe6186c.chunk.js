"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkwebofai_theme"] = self["webpackChunkwebofai_theme"] || []).push([["src_blocks_footer_block_index_js"],{

/***/ "./src/blocks/footer_block/index.js":
/*!******************************************!*\
  !*** ./src/blocks/footer_block/index.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _style_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./style.scss */ \"./src/blocks/footer_block/style.scss\");\n/* harmony import */ var _scripts_functions_imageLazyLoading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../scripts/functions/imageLazyLoading */ \"./src/scripts/functions/imageLazyLoading.js\");\n/* harmony import */ var _scripts_general_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../scripts/general/animations */ \"./src/scripts/general/animations/index.js\");\n\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (async function () {\n  let footer = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;\n  (0,_scripts_general_animations__WEBPACK_IMPORTED_MODULE_2__.animations)(footer);\n  (0,_scripts_functions_imageLazyLoading__WEBPACK_IMPORTED_MODULE_1__.imageLazyLoading)(footer);\n});\n\n//# sourceURL=webpack://webofai_theme/./src/blocks/footer_block/index.js?");

/***/ }),

/***/ "./src/blocks/footer_block/style.scss":
/*!********************************************!*\
  !*** ./src/blocks/footer_block/style.scss ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://webofai_theme/./src/blocks/footer_block/style.scss?");

/***/ })

}]);