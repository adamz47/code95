"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkwebofai_theme"] = self["webpackChunkwebofai_theme"] || []).push([["src_blocks_wp_collection_block_index_js"],{

/***/ "./src/blocks/wp_collection_block/index.js":
/*!*************************************************!*\
  !*** ./src/blocks/wp_collection_block/index.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _style_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./style.scss */ \"./src/blocks/wp_collection_block/style.scss\");\n/* harmony import */ var gsap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! gsap */ \"./node_modules/gsap/index.js\");\n/* harmony import */ var gsap_SplitText__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! gsap/SplitText */ \"./node_modules/gsap/SplitText.js\");\n/* harmony import */ var _scripts_functions_imageLazyLoading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../scripts/functions/imageLazyLoading */ \"./src/scripts/functions/imageLazyLoading.js\");\n/* harmony import */ var _scripts_general_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../scripts/general/animations */ \"./src/scripts/general/animations/index.js\");\n/* harmony import */ var _scripts_functions_requestBodyGenerator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../scripts/functions/requestBodyGenerator */ \"./src/scripts/functions/requestBodyGenerator.js\");\n/* harmony import */ var _scripts_functions_stringToHTML__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../scripts/functions/stringToHTML */ \"./src/scripts/functions/stringToHTML.js\");\n/* harmony import */ var lodash_function__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash/function */ \"./node_modules/lodash/function.js\");\n/* harmony import */ var lodash_function__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_function__WEBPACK_IMPORTED_MODULE_7__);\n\n\n\n\n\n\n\n\ngsap__WEBPACK_IMPORTED_MODULE_1__.gsap.registerPlugin(gsap_SplitText__WEBPACK_IMPORTED_MODULE_2__.SplitText);\n\n/**\n *\n * @param block {HTMLElement}\n * @returns {Promise<void>}\n */\nconst wpCollectionBlock = async block => {\n  const postsContainer = block.querySelector('[posts-container]');\n  const loadMore = block.querySelector('.load-more-wrapper');\n  const noPosts = block.querySelector('.no-posts');\n  let loadMoreStatus = !loadMore?.classList.contains('hidden');\n  loadMore?.addEventListener('click', async () => {\n    if (loadMore.classList.contains('loading')) return;\n    loadMore.classList.add('loading');\n    loadMore.classList.remove('hidden');\n    noPosts.classList.remove('active');\n    const response = await fetch(theme_ajax_object.ajax_url, {\n      method: 'POST',\n      body: (0,_scripts_functions_requestBodyGenerator__WEBPACK_IMPORTED_MODULE_5__.requestBodyGenerator)(loadMore)\n    });\n    loadMore.classList.remove('loading');\n    const hasMorePages = !!response.headers.get('X-WP-Has-More-Pages');\n    const totalPages = +response.headers.get('X-WP-Total-Pages');\n    noPosts.classList.toggle('active', totalPages === 0);\n    loadMore.classList.toggle('hidden', !hasMorePages);\n    loadMoreStatus = hasMorePages;\n    const htmlString = await response.json();\n    const oldArgs = JSON.parse(loadMore.dataset.args);\n    oldArgs.paged++;\n    loadMore.dataset.args = JSON.stringify(oldArgs);\n    const posts = (0,_scripts_functions_stringToHTML__WEBPACK_IMPORTED_MODULE_6__.stringToHTML)(htmlString.data);\n    for (let post of posts) {\n      postsContainer.appendChild(post);\n    }\n    (0,_scripts_general_animations__WEBPACK_IMPORTED_MODULE_4__.animations)(posts);\n    (0,_scripts_functions_imageLazyLoading__WEBPACK_IMPORTED_MODULE_3__.imageLazyLoading)(posts);\n  });\n  console.log('sdfsdfsdf');\n  function loadMoreClicker() {\n    loadMore?.click();\n    loadMore?.classList.add('none-floating');\n  }\n  const debouncedScrollHandler = (0,lodash_function__WEBPACK_IMPORTED_MODULE_7__.debounce)(() => !loadMore.matches('.loading, .hidden') && loadMoreClicker(), 300, {\n    leading: true,\n    maxWait: 500\n  });\n  const scrollHandler = () => {\n    0 >= block.getBoundingClientRect().bottom - window.innerHeight * (window.innerWidth <= 600 ? 5 : 3) && debouncedScrollHandler();\n  };\n  window.addEventListener('scroll', scrollHandler);\n  const textContainer = block.querySelector(\".placeholder\");\n  const myInput = block.querySelector(\".search-field\");\n  myInput?.addEventListener(\"focus\", function () {\n    textContainer.classList.add(\"hide\");\n  });\n  let split;\n  let animation = gsap__WEBPACK_IMPORTED_MODULE_1__.gsap.timeline({});\n  const blockAnimations = () => {\n    split = new gsap_SplitText__WEBPACK_IMPORTED_MODULE_2__.SplitText(textContainer, {\n      type: \"chars\"\n    });\n    animation.from(split.chars, {\n      delay: .5,\n      opacity: 0,\n      duration: .05,\n      ease: \"power3\",\n      stagger: {\n        amount: 1.5\n      },\n      repeat: -1,\n      repeatDelay: 3\n    });\n  };\n  window.addEventListener('play-iv-st-animation', blockAnimations);\n  (0,_scripts_general_animations__WEBPACK_IMPORTED_MODULE_4__.animations)(block);\n  (0,_scripts_functions_imageLazyLoading__WEBPACK_IMPORTED_MODULE_3__.imageLazyLoading)(block);\n};\n/* harmony default export */ __webpack_exports__[\"default\"] = (wpCollectionBlock);\n\n//# sourceURL=webpack://webofai_theme/./src/blocks/wp_collection_block/index.js?");

/***/ }),

/***/ "./src/scripts/functions/requestBodyGenerator.js":
/*!*******************************************************!*\
  !*** ./src/scripts/functions/requestBodyGenerator.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   requestBodyGenerator: function() { return /* binding */ requestBodyGenerator; }\n/* harmony export */ });\nconst requestBodyGenerator = btn => {\n  const {\n    template,\n    action,\n    args\n  } = btn.dataset;\n  const data = new FormData();\n  data.append('args', args);\n  data.append('template', template);\n  data.append('_ajax_nonce', theme_ajax_object._ajax_nonce);\n  data.append('action', action ? action : 'more_posts');\n  return data;\n};\n\n//# sourceURL=webpack://webofai_theme/./src/scripts/functions/requestBodyGenerator.js?");

/***/ }),

/***/ "./src/scripts/functions/stringToHTML.js":
/*!***********************************************!*\
  !*** ./src/scripts/functions/stringToHTML.js ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   stringToHTML: function() { return /* binding */ stringToHTML; }\n/* harmony export */ });\n/**\r\n * Convert a template string into HTML DOM nodes\r\n * @param  {String} str The template string\r\n * @return {Node[]} The template HTML\r\n */\nconst stringToHTML = function (str) {\n  const parser = new DOMParser();\n  const doc = parser.parseFromString(str, 'text/html');\n  return [...doc.body.children];\n};\n\n//# sourceURL=webpack://webofai_theme/./src/scripts/functions/stringToHTML.js?");

/***/ }),

/***/ "./src/blocks/wp_collection_block/style.scss":
/*!***************************************************!*\
  !*** ./src/blocks/wp_collection_block/style.scss ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("__webpack_require__.r(__webpack_exports__);\n// extracted by mini-css-extract-plugin\n\n\n//# sourceURL=webpack://webofai_theme/./src/blocks/wp_collection_block/style.scss?");

/***/ })

}]);