<?php
get_header();
wp_redirect( home_url() );
get_footer();
