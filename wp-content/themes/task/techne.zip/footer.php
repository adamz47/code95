<?php wp_footer(); ?>
<!--Footer ACF-->
<?php

?>
<!--region footer-->
<!-- remove footer if page template if full with no header and footer-->
<?php if (!is_page_template('templates/full-width-no-header-footer.php')): ?>
  <footer>
    <div class="container">
    </div>
  </footer>
<?php endif; ?>
</main>
<!-- General Custom Modal-->
<?php
?>
</body>
</html>
