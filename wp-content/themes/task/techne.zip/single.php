<?php
get_header();
$post_id = get_the_ID();
$thumbnail_id = get_the_post_thumbnail($post_id);
$post_title = get_the_title($post_id);
$dimensions = get_field('dimensions', $post_id);
$args = array(
  'post_type' => 'post',
  'posts_per_page' => 3,
  'order' => 'DESC',
  'orderby' => 'ID',
  'post__not_in' => array($post_id),
);

$relatedPosts = new WP_Query($args);

$categories = get_the_category($post_id);
$first_category = '';
$category_url = '';
if (!empty($categories)) {
  $first_category = $categories[0];
  $category_url = get_category_link($first_category->term_id);
  $first_category = $first_category->name;
}

if (have_posts()): the_post(); ?>

  <div class="single-post-wrapper">
    <div class="container">
      <div class="single-wrapper">
        <div class="cat-name">
          <?= $first_category ?>
        </div>
        <picture class="aspect-ratio">
          <?= $thumbnail_id ?>
        </picture>
        <h3 class="post-title"><?= $post_title ?></h3>
        <div class="dimensions"><?= $dimensions ?></div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php
get_footer();
